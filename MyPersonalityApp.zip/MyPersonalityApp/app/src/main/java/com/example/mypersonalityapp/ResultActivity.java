package com.example.mypersonalityapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    private TextView textViewResult;
    private TextView textViewScore;
    private Button buttonRetake;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        
        textViewResult = findViewById(R.id.textViewResult);
        textViewScore = findViewById(R.id.textViewScore);
        buttonRetake = findViewById(R.id.buttonRetake);

        Intent intent = getIntent();
        double extraversion = intent.getDoubleExtra("Extraversion", 0.0);
        double agreeableness = intent.getDoubleExtra("Agreeableness", 0.0);
        double conscientiousness = intent.getDoubleExtra("Conscientiousness", 0.0);
        double emotionalStability = intent.getDoubleExtra("Emotional Stability", 0.0);
        double openness = intent.getDoubleExtra("Openness", 0.0);

        String personalityType = getIntent().getStringExtra("PERSONALITY_TYPE");

        textViewResult.setText("Your Personality Type: " + personalityType);

        String breakdown = String.format(
                "Extraversion: %.2f\nAgreeableness: %.2f\nConscientiousness: %.2f\nEmotional Stability: %.2f\nOpenness: %.2f",
                extraversion, agreeableness, conscientiousness, emotionalStability, openness
        );

        textViewScore.setText(breakdown);


        // Retake Test: Restart the quiz when the button is clicked.
        buttonRetake.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ResultActivity.this, QuizActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }



}
